-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 24, 2015 at 11:49 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do_test`
--
CREATE DATABASE IF NOT EXISTS `to_do_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `to_do_test`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `task_name` varchar(255) DEFAULT NULL,
  `due_date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=320 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tasks_categories`
--

CREATE TABLE IF NOT EXISTS `tasks_categories` (
  `id` bigint(20) unsigned NOT NULL,
  `task_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks_categories`
--

INSERT INTO `tasks_categories` (`id`, `task_id`, `category_id`) VALUES
(1, 64, 193),
(2, 65, 194),
(3, 65, 195),
(4, 207, 76),
(5, 208, 77),
(6, 209, 77),
(7, 221, 88),
(8, 222, 89),
(9, 223, 89),
(10, 235, 100),
(11, 236, 101),
(12, 237, 101),
(13, 249, 112),
(14, 250, 113),
(15, 251, 113),
(16, 263, 114),
(17, 264, 115),
(18, 264, 116),
(19, 265, 127),
(20, 266, 128),
(21, 267, 128),
(22, 279, 130),
(23, 280, 131),
(24, 280, 132),
(25, 281, 144),
(26, 282, 145),
(27, 283, 145),
(28, 284, 146),
(29, 285, 157),
(30, 286, 158),
(31, 287, 158),
(33, 300, 160),
(34, 301, 161),
(35, 301, 162),
(36, 302, 174),
(37, 303, 175),
(38, 304, 175),
(40, 317, 177),
(41, 318, 178),
(42, 318, 179);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks_categories`
--
ALTER TABLE `tasks_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=181;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=320;
--
-- AUTO_INCREMENT for table `tasks_categories`
--
ALTER TABLE `tasks_categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
